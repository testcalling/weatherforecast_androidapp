package temperature.widget;


import trenutna.temperatura.R;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RemoteViews;
import android.widget.TextView;



public class MyWidgetProvider extends AppWidgetProvider {
	
	public static final String LOCATION = "temperature.widget.LOCATION";
	String LOC;
	public static final String TEMPERATURE = "temperature.widget.TEMPERATURE";
	String TEMP;
	int IMAGE;

	@Override
	public void onReceive(Context context, Intent intent) {
	    super.onReceive(context, intent);
	    Bundle extras = intent.getExtras(); 
        LOC = extras.getString("LOCATION");
        TEMP =extras.getString("TEMPERATURE");
        IMAGE =extras.getInt("IMAGE");
	}
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
			int[] appWidgetIds) {
		   
		RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_weather);
		remoteViews.setTextViewText(R.id.location,LOC );
		remoteViews.setTextViewText(R.id.temperature, TEMP);
		remoteViews.setImageViewResource(R.id.weather_icon, IMAGE);
		pushWidgetUpdate(context, remoteViews);
	}

	public static PendingIntent buildButtonPendingIntent(Context context) {
		Intent intent = new Intent();
	    intent.setAction("pl.looksok.intent.action.CHANGE_PICTURE");
	    return PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
	}

	public static void pushWidgetUpdate(Context context, RemoteViews remoteViews) {
		ComponentName myWidget = new ComponentName(context, MyWidgetProvider.class);
	    AppWidgetManager manager = AppWidgetManager.getInstance(context);
	    manager.updateAppWidget(myWidget, remoteViews);		
	}
}
