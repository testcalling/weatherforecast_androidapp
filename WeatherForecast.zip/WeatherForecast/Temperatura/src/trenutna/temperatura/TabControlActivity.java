package trenutna.temperatura;

import weatherforecast.MainActivity;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
 
public class TabControlActivity extends TabActivity {
    /** Called when the activity is first created. */
	TabHost tabHost;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_control);
         
         tabHost= getTabHost();
         

        TabSpec photospec = tabHost.newTabSpec("Current");
      
        photospec.setIndicator("Current", getResources().getDrawable(R.drawable.set_1));
        Intent photosIntent = new Intent(this, ActivityWeatherSettings.class);
        photospec.setContent(photosIntent);
  
     
        TabSpec songspec = tabHost.newTabSpec("Forecast");        
        songspec.setIndicator("Forecast", getResources().getDrawable(R.drawable.set2));
        Intent songsIntent = new Intent(this, MainActivity.class);
      

        songspec.setContent(songsIntent);
   
        tabHost.addTab(photospec); 
        tabHost.addTab(songspec); 
       
    
   
    }
    public TabHost getMyTabHost() { return tabHost; }
}