

package weatherforecast;


import java.util.Locale;


import com.google.ads.AdRequest;
import com.google.ads.AdSize;
import com.google.ads.AdView;

import temperature.widget.MyWidgetIntentReceiver;
import trenutna.temperatura.ActivityWeatherSettings;

import trenutna.temperatura.R;
import zh.wang.android.apis.yweathergetter4a.WeatherInfo;
import zh.wang.android.apis.yweathergetter4a.WeatherInfo.ForecastInfo;
import zh.wang.android.apis.yweathergetter4a.YahooWeather;
import zh.wang.android.apis.yweathergetter4a.YahooWeather.SEARCH_MODE;
import zh.wang.android.apis.yweathergetter4a.YahooWeatherExceptionListener;
import zh.wang.android.apis.yweathergetter4a.YahooWeatherInfoListener;




import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements YahooWeatherInfoListener,
    YahooWeatherExceptionListener {
	
	private ImageView mIvWeather0;
	private TextView mTvWeather0;
	private TextView mTvErrorMessage;
	private TextView mTvTitle;
	private EditText mEtAreaOfCity;
	private Button mBtSearch;
	private Button mBtGPS;
	private LinearLayout mWeatherInfosLayout;


	private YahooWeather mYahooWeather = YahooWeather.getInstance(5000, 5000, true);

    private ProgressDialog mProgressDialog;
    private static final String AD_UNIT_ID_GOES_HERE = "a1533da32ed79b0";
	public AdView adView;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity_layout);
        Intent intent = getIntent();
		String LOCATION = intent.getExtras().getString("LOCATION");
		String lang = intent.getExtras().getString("lang");
		if(lang!=null){
		changeLang(lang);
		}
		
	
        mYahooWeather.setExceptionListener(this);
        
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mProgressDialog.setTitle("Please wait...");
      
        
    	mTvTitle = (TextView) findViewById(R.id.textview_title);
    	mTvTitle.setTypeface(Typeface.SERIF, Typeface.BOLD);
		mTvWeather0 = (TextView) findViewById(R.id.textview_weather_info_0);
        mTvWeather0.setTypeface(Typeface.SERIF, Typeface.BOLD);
		mTvErrorMessage = (TextView) findViewById(R.id.textview_error_message);
		mIvWeather0 = (ImageView) findViewById(R.id.imageview_weather_info_0);
	
        mEtAreaOfCity = (EditText) findViewById(R.id.edittext_area);
       
        mEtAreaOfCity.setText(LOCATION);
        
        updateLocation();
		
        mBtSearch = (Button) findViewById(R.id.search_button);
        mBtSearch.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				updateLocation();
			}
		});
        
        mBtGPS = (Button) findViewById(R.id.gps_button);
        mBtGPS.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				searchByGPS();
				showProgressDialog();
			}
		});

        mWeatherInfosLayout = (LinearLayout) findViewById(R.id.weather_infos);
        mWeatherInfosLayout.setGravity(Gravity.CENTER);
        adView = new AdView(this, AdSize.BANNER, AD_UNIT_ID_GOES_HERE);
		LinearLayout layout = (LinearLayout) findViewById(R.id.linear11);
	    layout.addView(adView);
	    AdRequest adRequest = new AdRequest();
	    boolean inEmulator = "generic".equals(Build.BRAND.toLowerCase());
	    if (inEmulator) 
	    {
	        adRequest.addTestDevice(AdRequest.TEST_EMULATOR);
	    } 
	    else 
	    {
	        adRequest.addTestDevice("11111111101111111110111111111011");
	    }
	    adView.loadAd(adRequest);
	    buttonTabAction();
        
    }
    Button btnCurrent;
    public void buttonTabAction()
	{
    	btnCurrent = (Button)findViewById(R.id.btCurrent);
    	btnCurrent.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				
				/* Intent intent = new Intent(MainActivity.this,ActivityWeatherSettings.class);
				 //intent.putExtra("LOCATION", m_TextLocation.getText().toString());

				// intent.putExtra("lang", lang);
				 MainActivity.this.startActivity(intent);*/
				finish();
			}
		});
		
	}
	
    public void updateLocation()
    {
    	String _location = mEtAreaOfCity.getText().toString();
		if (!TextUtils.isEmpty(_location)) {
			InputMethodManager imm = (InputMethodManager)getSystemService(
          	      Context.INPUT_METHOD_SERVICE);
          	imm.hideSoftInputFromWindow(mEtAreaOfCity.getWindowToken(), 0);
            searchByPlaceName(_location);	
            showProgressDialog();
		} else {
			Toast.makeText(getApplicationContext(), "location is not inputted", 1).show();
		}
    }
   
    
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		hideProgressDialog();
		mProgressDialog = null;
		super.onDestroy();
	}
	 
	@Override
	public void gotWeatherInfo(WeatherInfo weatherInfo) {
		// TODO Auto-generated method stub
		String date = getResources().getString(R.string.date);
		String weather = getResources().getString(R.string.weather);
		String lowhigh = getResources().getString(R.string.lowhigh);
		String tempC = getResources().getString(R.string.tempC);
		String tempF = getResources().getString(R.string.tempF);
		String windSpeed = getResources().getString(R.string.windSpeed);
		String windDirection = getResources().getString(R.string.windDirection);
		String pressure = getResources().getString(R.string.pressure);
		String sunrise = getResources().getString(R.string.sunrise);
		String sunset = getResources().getString(R.string.sunset);
		String rising = getResources().getString(R.string.rising);
		String humidity = getResources().getString(R.string.str_humidity);
		String visi = getResources().getString(R.string.str_visi);
		String current = getResources().getString(R.string.current);
		
		
		
		hideProgressDialog();
		
		
        if (weatherInfo != null) {
        	setNormalLayout();
        	if (mYahooWeather.getSearchMode() == SEARCH_MODE.GPS) {
        		//mEtAreaOfCity.setText("YOUR CURRENT LOCATION");
        	}
        	mWeatherInfosLayout.removeAllViews();
			mTvTitle.setText(
			     //    weatherInfo.getTitle() + "\n"
					  weatherInfo.getLocationCity() + ", "
					+ weatherInfo.getWOEIDCountry());
		
			mTvWeather0.setText("======== "+current+" ========" + "\n" +
					            date+": " + weatherInfo.getCurrentConditionDate() + "\n" +
							   weather+": " + weatherInfo.getCurrentText() + "\n" +
						       tempC+": " + weatherInfo.getCurrentTempC() + "\n" +
						       tempF+": " + weatherInfo.getCurrentTempF() + "\n" +
						       
						     
					           windDirection+": " + weatherInfo.getWindDirection() + "\n" +
						       windSpeed+": " + weatherInfo.getWindSpeed() + "\n" +
					           humidity+": " + weatherInfo.getAtmosphereHumidity() + "\n" +
						       pressure+": " + weatherInfo.getAtmospherePressure() + "\n" +
					           visi+": " + weatherInfo.getAtmosphereVisibility()+ "\n" +
					           sunrise+": " + weatherInfo.getAstronomySunrise()+ "\n" +
					           sunset+": " + weatherInfo.getAstronomySunset()+ "\n" +
					           rising+": " + weatherInfo.getAtmosphereRising()+ "\n" 
					     
					           );
			
			if (weatherInfo.getCurrentConditionIcon() != null) {
				mIvWeather0.setImageBitmap(weatherInfo.getCurrentConditionIcon());
			}
		
			for (int i = 0; i < YahooWeather.FORECAST_INFO_MAX_SIZE; i++) {
				final LinearLayout forecastInfoLayout = (LinearLayout) 
						getLayoutInflater().inflate(R.layout.forecastinfo, null);
				forecastInfoLayout.setGravity(Gravity.CENTER);
				final TextView tvWeather = (TextView) forecastInfoLayout.findViewById(R.id.textview_forecast_info);
				tvWeather.setTypeface(Typeface.SERIF, Typeface.BOLD);
				final ForecastInfo forecastInfo = weatherInfo.getForecastInfoList().get(i);
				tvWeather.setText("===== " + forecastInfo.getForecastDay() +", "+ forecastInfo.getForecastDate() +" =====" + "\n" +
				                  // date+": " + forecastInfo.getForecastDate() + "\n" +
				                   
				                   forecastInfo.getForecastTempLowC() +" - "+ forecastInfo.getForecastTempHighC()+ " ºC | " + forecastInfo.getForecastTempLowF() +" - "+ forecastInfo.getForecastTempHighF()+" ºF\n"+
				                  // weather+": " + forecastInfo.getForecastText() + "\n"
				                  weather+": " +forecastInfo.getForecastText()
				                   //  lowhigh+": " + forecastInfo.getForecastTempLowC() +" - "+ forecastInfo.getForecastTempHighC()+ " ºC\n" +     
						         //  lowhigh+": " + forecastInfo.getForecastTempLowF() +" - "+ forecastInfo.getForecastTempHighF()+" ºF\n"
						       			           );
				
				final ImageView ivForecast = (ImageView) forecastInfoLayout.findViewById(R.id.imageview_forecast_info);
				if (forecastInfo.getForecastConditionIcon() != null) {
					ivForecast.setImageBitmap(forecastInfo.getForecastConditionIcon());
					
				}
				mWeatherInfosLayout.addView(forecastInfoLayout);
			}
        } else {
        	setNoResultLayout();
        }
        InputMethodManager imm = (InputMethodManager)getSystemService(
			      Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(((EditText)findViewById(R.id.edittext_area)).getWindowToken(), 0);
			getWindow().setSoftInputMode(
				      WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
	}

    @Override
    public void onFailConnection(final Exception e) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void onFailParsing(final Exception e) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void onFailFindLocation(final Exception e) {
        // TODO Auto-generated method stub
        
    }

	private void setNormalLayout() {
		mWeatherInfosLayout.setVisibility(View.VISIBLE);
	
		mTvTitle.setVisibility(View.VISIBLE);
		mTvErrorMessage.setVisibility(View.INVISIBLE);
	}
	
	private void setNoResultLayout() {
		mTvTitle.setVisibility(View.INVISIBLE);
		mWeatherInfosLayout.setVisibility(View.INVISIBLE);
		mTvErrorMessage.setVisibility(View.VISIBLE);
		mTvErrorMessage.setText(getResources().getString(R.string.noresult));
	    mProgressDialog.cancel();
	}
	
	private void searchByGPS() {
		mYahooWeather.setNeedDownloadIcons(true);
		mYahooWeather.setSearchMode(SEARCH_MODE.GPS);
		mYahooWeather.queryYahooWeatherByGPS(getApplicationContext(), this);
	}
	
	private void searchByPlaceName(String location) {
		mYahooWeather.setNeedDownloadIcons(true);
		mYahooWeather.setSearchMode(SEARCH_MODE.PLACE_NAME);
		mYahooWeather.queryYahooWeatherByPlaceName(getApplicationContext(), location,this);
	}
	
	private void showProgressDialog() {
      	if (mProgressDialog != null && mProgressDialog.isShowing()) {
      		mProgressDialog.cancel();
      	}
      	String wait = getResources().getString(R.string.strOnSearching);
        mProgressDialog = new ProgressDialog(MainActivity.this);
        mProgressDialog.setMessage(wait+"...");
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mProgressDialog.show();
	}
	
	private void hideProgressDialog() {
		if (mProgressDialog != null && mProgressDialog.isShowing()) {
			mProgressDialog.cancel();
		}
	}
	
	//Language
	 private Locale myLocale;
	public void changeLang(String lang)
	{
	    if (lang.equalsIgnoreCase(""))
	     return;
	    myLocale = new Locale(lang);
	    saveLocale(lang);
	    Locale.setDefault(myLocale);
	    android.content.res.Configuration config = new android.content.res.Configuration();
	    config.locale = myLocale;
	    getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
	    updateTexts();
	}

	private void updateTexts() {
	     Button buttonSearch = (Button)findViewById(R.id.search_button);
		 buttonSearch.setText(R.string.searchNow);
		 Button buttonGPS = (Button)findViewById(R.id.gps_button);
		 buttonGPS.setText(R.string.buttonGPS);
	}
	public void saveLocale(String lang)
	{
	    String langPref = "Language";
	    SharedPreferences prefs = getSharedPreferences("CommonPrefs", Activity.MODE_PRIVATE);
	    SharedPreferences.Editor editor = prefs.edit();
	    editor.putString(langPref, lang);
	    editor.commit();
	}

	public void loadLocale()
	{
	    String langPref = "Language";
	    SharedPreferences prefs = getSharedPreferences("CommonPrefs", Activity.MODE_PRIVATE);
	    String language = prefs.getString(langPref, "");
	    changeLang(language);
	}


}
