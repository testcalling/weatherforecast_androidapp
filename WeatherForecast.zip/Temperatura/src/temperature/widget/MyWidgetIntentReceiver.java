package temperature.widget;



import trenutna.temperatura.R;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RemoteViews;



public class MyWidgetIntentReceiver extends BroadcastReceiver {

	private static int clickCount = 0;
	
	public static final String LOCATION = "temperature.widget.LOCATION";
	String LOC;
	public static final String TEMPERATURE = "temperature.widget.TEMPERATURE";
	String TEMP;
	int IMAGE;
	@Override
	public void onReceive(Context context, Intent intent) {
		    Bundle extras = intent.getExtras(); 
	         LOC = extras.getString("LOCATION");
	         TEMP =extras.getString("TEMPERATURE");
	         IMAGE =extras.getInt("IMAGE");
	         updateWidgetPictureAndButtonListener(context);
	    
		/*if(intent.getAction().equals("pl.looksok.intent.action.CHANGE_PICTURE")){
			updateWidgetPictureAndButtonListener(context);
		}*/
	}

	private void updateWidgetPictureAndButtonListener(Context context) {
		RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_weather);
		//
		
	
		remoteViews.setTextViewText(R.id.location, LOC);
		remoteViews.setTextViewText(R.id.temperature, TEMP);
		remoteViews.setImageViewResource(R.id.weather_icon, IMAGE);
		//remoteViews.setOnClickPendingIntent(R.id.widget_button, MyWidgetProvider.buildButtonPendingIntent(context));
		
		MyWidgetProvider.pushWidgetUpdate(context.getApplicationContext(), remoteViews);
	}

	/*private int getImageToSet() {
		clickCount++;
		return clickCount % 2 == 0 ? R.drawable.a17 : R.drawable.a0;
	}*/
}
