			         		  

package trenutna.temperatura;

import java.text.DateFormat;



import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;




import java.util.List;


import temperature.widget.MyWidgetIntentReceiver;
import trenutna.temperatura.controller.WeatherCustomDialog;
import trenutna.temperatura.controller.WidgetWeather;
import trenutna.temperatura.model.WeatherDataModel;
import trenutna.temperatura.model.WeatherInfo;
import trenutna.temperatura.model.WeatherPreferences;
import trenutna.temperatura.model.YahooWeatherHelper;
import trenutna.temperatura.view.ContextMenuAdapter;
import trenutna.temperatura.view.ContextMenuItem;
import weatherforecast.MainActivity;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;
import android.widget.Toast;





import com.google.ads.AdRequest;
import com.google.ads.AdSize;
import com.google.ads.AdView;


public class ActivityWeatherSettings extends Activity  {

	private static final String TAG = "ActivityYahoo";
	
	private static final int DIALOG_TYPE_USER_AGREEMENT = 1;
	
	private static final int REG_CHANGELOCATION = 1;

	private static final int REG_GET_WEATHER_START = 100;

	private static final int REG_GET_WEATHER_FINISH = 101;
	
	private static final int ONE_MINUTE = 60*1000;

	private WeatherInfo m_WeatherInfo;
	
	private WeatherPreferences m_Preferneces;
	
	private WeatherDataModel m_DataModel;
	
	private TextView m_TextLocation;
	
	private TextView m_Temperature;

	private TextView m_Humimidy;
	
	private TextView  m_Visibility;

	private TextView m_Date;

	private ImageView m_WeatherIcon;

	Handler m_HandleRequest;

	AlertDialog m_Dialog;	
	
	Button btnCurrent;
	Button btnForecast;

	private ContextMenuAdapter m_contextAdapter;

	AlertDialog m_Alert;

	private static final String AD_UNIT_ID_GOES_HERE = "a1533da32ed79b0";
	public AdView adView;

	public void share()
	{
		Intent sharingIntent = new Intent(Intent.ACTION_SEND);
		sharingIntent.setType("text/plain");
		sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Weather Forecast:\nplay.google.com/store/apps/details?id=trenutna.temperatura\nFacebook: www.facebook.com/WeatherForecastAndroidApp");
		sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
		startActivity(Intent.createChooser(sharingIntent, "Share via")); 
	}
	public void adMob()
	{
		adView = new AdView(this, AdSize.BANNER, AD_UNIT_ID_GOES_HERE);
		LinearLayout layout = (LinearLayout) findViewById(R.id.lineara);
	    layout.addView(adView);
		AdRequest adRequest = new AdRequest();
	    boolean inEmulator = "generic".equals(Build.BRAND.toLowerCase());
	    if (inEmulator) 
	    {
	        adRequest.addTestDevice(AdRequest.TEST_EMULATOR);
	    } 
	    else 
	    {
	        adRequest.addTestDevice("11111111101111111110111111111011");
	    }
	    adView.loadAd(adRequest);
	}
	public void buttonTabAction()
	{
		btnForecast = (Button)findViewById(R.id.btnForecast);
		btnForecast.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				
				 Intent intent = new Intent(ActivityWeatherSettings.this, MainActivity.class);
				 intent.putExtra("LOCATION", m_TextLocation.getText().toString());

				 intent.putExtra("lang", lang);
				 ActivityWeatherSettings.this.startActivity(intent);
			}
		});
		
	}
	
	public void widgetUpdate()
	{
		Intent intent = new Intent(MyWidgetIntentReceiver.LOCATION);
		intent.putExtra("LOCATION", m_TextLocation.getText().toString());
		intent.putExtra("TEMPERATURE", m_Temperature.getText().toString());
		intent.putExtra("IMAGE", nCode);
		getApplicationContext().sendBroadcast(intent);
	}
	

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_setting);
        
       
	    adMob();
	    
	    Button podeli = (Button)findViewById(R.id.Podeli);
        podeli.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {

			   share();
			}
		});
	    

        boolean bResult = initializeData();
        
        if (bResult != false ){
           
        	bResult = initializeView();
        	drawWeatherScreen();
        	
        }
        if (bResult == false){
        	Log.e(TAG,"Init data failed");
        	finish();
        	return;
        }
        
		if (m_Preferneces.getAcceptAgreement() == false){
			showDialog(DIALOG_TYPE_USER_AGREEMENT);
			
		} else {
		
			drawWeatherScreen();
		
			}  
		buttonTabAction();
	
	  fillFolksText();
		
    }
   
    MenuItem item1;
    MenuItem item2;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_weather_screen, menu);
       item1 =(MenuItem) menu.findItem(R.id.menu_setting);
       item2 =(MenuItem) menu.findItem(R.id.menu_weather);
    
     
       
        return true;
    }
    public void fillFolksText()
    {
    	
    	TextView randomFolks=(TextView)findViewById(R.id.randomFolks);
		String text=null;
		String langPref = "Language";
	    SharedPreferences prefs = getSharedPreferences("CommonPrefs", Activity.MODE_PRIVATE);
	    String language = prefs.getString(langPref, "");
	    String s = getResources().getString(R.string.option_menu_setting);
	 
		if(language.equals("en")|| language.equals("fr") || language.equals("es") || language.equals("de")||s.equals("Settings") ){
		text=getFolkText();
		randomFolks.setText(text);
		
		}
		else if(language.equals("sr") || language.equals("hr") || language.equals("ba")){
		
		text=getNarodneText();
		
		randomFolks.setText(text);
		}
	   final String t =text;
		randomFolks.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
             
				Intent sharingIntent = new Intent(Intent.ACTION_SEND);
				sharingIntent.setType("text/plain");
				sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, t+"\n\nWeather Forecast:\nplay.google.com/store/apps/details?id=trenutna.temperatura\nFacebook: www.facebook.com/WeatherForecastAndroidApp");
				sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
				startActivity(Intent.createChooser(sharingIntent, "Share via")); 
			}
		});
		
    }
  
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	int nSelectID = item.getItemId();
    	
    	switch(nSelectID){
    	
    	case R.id.menu_setting:
    		selectWeatherSetting();
    		break;
    	case R.id.menu_weather:
    	{
    		 Intent intent = new Intent(Intent.ACTION_VIEW);
    		    
    		    intent.setData(Uri.parse("market://details?id=trenutna.temperatura"));
    		    if (!MyStartActivity(intent)) {
    		    	  intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=trenutna.temperatura"));
    		        if (!MyStartActivity(intent)) {
    		          
    		            Toast.makeText(this, "Could not open Android market, please install the market app.", Toast.LENGTH_SHORT).show();
    		        }
    		    }
    		  
    		  
    	}
    		break;
    		
    		default:
    			Log.e(TAG,"Why you don't handle this case");
    			break;
    	}
    	
        return super.onOptionsItemSelected(item);
    }	
    private boolean MyStartActivity(Intent aIntent) {
        try
        {
            startActivity(aIntent);
            return true;
        }
        catch (ActivityNotFoundException e)
        {
            return false;
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	switch (requestCode){
    	case REG_CHANGELOCATION:
    		updateDataOfCurrentLocation();
    	
    		break;
    		
    		default:
    			Log.w(TAG,"Not handle request code:"+requestCode);
    			break;
    	}
    	super.onActivityResult(requestCode, resultCode, data);
    }
    
    private void updateDataOfCurrentLocation(){
    	requestUpdateWeather();
    	
    }

    private void requestUpdateWeather(){
    	Message msgFetchData = new Message();
    	msgFetchData.what = REG_GET_WEATHER_START;
    	m_HandleRequest.sendMessage(msgFetchData);   
    	
    }
   
	private void initializeHandleRequest(){
		final Runnable m_Runnable = new Runnable(){

			public void run() {
				requestUpdateWeather();
				
			}			
		};
		
		m_HandleRequest = new Handler(){
			@Override
			public void handleMessage(Message message) {
				int nRequest = message.what;
				
				switch(nRequest){
				case REG_GET_WEATHER_START:
			    	String strWOEID = m_Preferneces.getLocation();
			    	if (strWOEID == null){
			    		Log.e(TAG,"Can not get WOEID");
			    
			    		displayNotifyCation(R.string.strFetchFailed);
			    		return;
			    	} else {
				  
				        m_WeatherInfo = m_DataModel.getWeatherData(strWOEID);			
			    	}
					
					Message msgRegSearch = new Message();
					msgRegSearch.what = REG_GET_WEATHER_FINISH;
					sendMessage(msgRegSearch);
					break;
					
				case REG_GET_WEATHER_FINISH:
			    	if (m_WeatherInfo != null){
			    		updateWeatherInfo(m_WeatherInfo);
			    		notifyUpdateTime();
			    	}	
			    	
					m_HandleRequest.postDelayed(m_Runnable, (ONE_MINUTE*m_Preferneces.getTimeUpdate()));
			   
					
			    	break;
					 
					 default:
						 Log.e(TAG,"Can not handle this message");
						 break;
				}
			}
        };		
	}    

	private void notifyUpdateTime(){
		Intent intentSettingUpdate = new Intent(WidgetWeather.UPDATE_WEATHER);
		this.sendBroadcast(intentSettingUpdate);
		startSer();
		//widgetUpdate();
		
	}
    

    private void displayNotifyCation(int nResID){
		Toast.makeText(getApplicationContext(), getString(nResID),
				Toast.LENGTH_LONG).show();    	
		
    }
    

    private void selectSetting(){
		Intent intent = new Intent(ActivityWeatherSettings.this,ActivityScreenLocation.class);
		startActivityForResult(intent, REG_CHANGELOCATION);  
		
    }

    
    private void selectTimeIntervalUpdating(){
    	
    	String minS =  getResources().getString(R.string.min);	
    	final String[] items = {getResources().getString(R.string.min5),minS, getResources().getString(R.string.hours1), getResources().getString(R.string.hours2)};

    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	builder.setTitle(R.string.selectTimeUpdate);
    	builder.setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener() {
    	    public void onClick(DialogInterface dialog, int item) {
    	     
    	    	int nTime = 30;
    	    	switch( item ){
    	    	case 0:
    	    		nTime = 5;
    	    		break;
    	    	case 1:
    	    		nTime = 30;
    	    		break;
    	    	case 2:
    	    		nTime = 180;
    	    		
    	    	case 3:
    	    		nTime = 720;
    	    		break;
    	    		
    	    		default:
    	    			break;
    	    	}
    	    	
    	    	m_Preferneces.setTimeUpdate(nTime);
    	    	m_Alert.dismiss();
    	    	updateWeatherInfo(m_WeatherInfo);
    	    }
    	});
    	
    	m_Alert = builder.create();  
    	m_Alert.show();
    }
  
    private void selectTempFormat(){
    	final CharSequence[] items = {"Celsius", "Fahrenheit"};

    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	builder.setTitle(R.string.selectTemperatureUnit);
    	builder.setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener() {
    	    public void onClick(DialogInterface dialog, int item) {
    	  
    	    	boolean bIsC = true;
    	    	switch( item ){
    	    	case 0:
    	    		bIsC = true;
    	    		break;
    	    	case 1:
    	    		bIsC = false;
    	    		
    	    		default:
    	    			break;
    	    	}
    	    	m_Preferneces.setTempFmt(bIsC);
    	    	m_Alert.dismiss();
    	    	notifyUpdateTime();
    	    	updateWeatherInfo(m_WeatherInfo);
    	    }
    	});
    	m_Alert = builder.create();  
    	m_Alert.show();
    }   
    public String lang;
    
    private void selectLanguage(){
    	final CharSequence[] items = {getResources().getString(R.string.english), getResources().getString(R.string.serbian),getResources().getString(R.string.croatian),getResources().getString(R.string.bosnian),getResources().getString(R.string.german),getResources().getString(R.string.spain),getResources().getString(R.string.france)};

    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	builder.setTitle(R.string.change_language);
    	
    /*	final TextView randomFolks=(TextView)findViewById(R.id.randomFolks);
		final String tex;*/
		
    	builder.setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener() {
    	    public void onClick(DialogInterface dialog, int item) {
    	        
    	    	switch( item ){
    	    	case 0:
    	    		
    	    		lang = "en";
    	  
    	    		//randomFolks.setText(getFolkText());
    	    		break;
    	    	case 1:
    	    
    	    		lang = "sr";
    	    	
    	    	
    	    		//randomFolks.setText(getNarodneText());
    	    		break;
    	    	case 2:
    	    	    
    	    		lang = "hr";
    	    		//randomFolks.setText(getNarodneText());
    	    		break;
    	    	case 3:
    	    	    
    	    		lang = "ba";
    	    	//	randomFolks.setText(getNarodneText());
    	    		break;
                case 4:
    	    	    
    	    		lang = "de";
    	    		//randomFolks.setText(getFolkText());
    	    		break;
               case 5:
    	    	    
    	    		lang = "es";
    	    		//randomFolks.setText(getFolkText());
    	    		break;
               case 6:
   	    	    
   	    		lang = "fr";
   	    	//	randomFolks.setText(getFolkText());
   	    		break;
    	    		default:
    	    			break;
    	    	}
    	    	
    	    	changeLang(lang);
    	    	fillFolksText();
    	    	m_Alert.dismiss();
    	    	
    	    }
    	});
    	m_Alert = builder.create();  
    	m_Alert.show();
    	

	   /*final String t =randomFolks.getText().toString();
		randomFolks.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
             
				Intent sharingIntent = new Intent(Intent.ACTION_SEND);
				sharingIntent.setType("text/plain");
				sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, t+"\n\nWeather Forecast:\nplay.google.com/store/apps/details?id=trenutna.temperatura\nFacebook: www.facebook.com/WeatherForecastAndroidApp");
				sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
				startActivity(Intent.createChooser(sharingIntent, "Share via")); 
			}
		});*/
    }
    private Locale myLocale;
public void changeLang(String lang)
{
    if (lang.equalsIgnoreCase(""))
     return;
    myLocale = new Locale(lang);
    saveLocale(lang);
    Locale.setDefault(myLocale);
    android.content.res.Configuration config = new android.content.res.Configuration();
    config.locale = myLocale;
    getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
    updateTexts();
}

public void saveLocale(String lang)
{
    String langPref = "Language";
    SharedPreferences prefs = getSharedPreferences("CommonPrefs", Activity.MODE_PRIVATE);
    SharedPreferences.Editor editor = prefs.edit();
    
    editor.putString(langPref, lang);
    editor.commit();
}

public void loadLocale()
{
    String langPref = "Language";
    SharedPreferences prefs = getSharedPreferences("CommonPrefs", Activity.MODE_PRIVATE);
    String language = prefs.getString(langPref, "");
    changeLang(language);
}

private void updateTexts()
{
    TextView humidityTitle = (TextView)findViewById(R.id.humidityTitle);
    humidityTitle.setText(R.string.str_humidity);
    TextView visibilityTitle = (TextView)findViewById(R.id.visiTitle);
    visibilityTitle.setText(R.string.str_visi);
    item1.setTitle(R.string.option_menu_setting);
    item2.setTitle(R.string.option_menu_weatherforecast);
    Button buttonCurrent = (Button)findViewById(R.id.btCurrent);
    buttonCurrent.setText(R.string.current);
	Button buttonForecast = (Button)findViewById(R.id.btnForecast);
	buttonForecast.setText(R.string.option_menu_weatherforecast);

}
    

    private boolean initializeView(){
    	m_TextLocation = (TextView)findViewById(R.id.location);
    	m_Temperature = (TextView)findViewById(R.id.temperature);
    	m_Humimidy = (TextView)findViewById(R.id.humidityValue);
    	m_Visibility = (TextView)findViewById(R.id.visiValue);
    	m_WeatherIcon = (ImageView) findViewById(R.id.weather_icon);
    	m_Date = (TextView)findViewById(R.id.dateTime);
  
    	if ((m_TextLocation == null) || (m_Temperature == null) || 
    			(m_Humimidy == null) || (m_WeatherIcon == null) ||
    			(m_Visibility == null) || (m_Date == null)){
    		Log.e(TAG,"View init failed");
    		return false;
    	}
    
   
    	return true;
    }
  
    private boolean initializeData(){
   
    	Context appContext = this.getApplicationContext();
    	
    
    	m_Preferneces = WeatherPreferences.getInstance(appContext);
    	if (m_Preferneces == null){
    		Log.e(TAG, "Get preference instance failed, check please");
    		return false;
    	}

    	m_DataModel = WeatherDataModel.getInstance();
    	if (m_DataModel == null){
    		Log.e(TAG,"Can not get data model");
    		return false;
    	}

    	initializeHandleRequest();
  
    	return true;
    }    
    

    private void drawWeatherScreen(){
    	drawTitle();
  
    	updateDataOfCurrentLocation();
    	
    
    	
    }
    int nCode;
    public Intent startSer()
    {
    	
    	Intent i = new Intent(this, ServiceNotification.class);
    	i.putExtra("LOCATION", m_TextLocation.getText().toString());
    	i.putExtra("TEMP", m_Temperature.getText().toString());
        i.putExtra("IMAGE", nCode);
    	
        startService(i);
         return i;
    	
    }
    public void stopSer()
    {
    	stopService(startSer());
    }
    private void updateWeatherInfo(WeatherInfo weatherInfo){
    	if (weatherInfo == null){
    		Log.e(TAG,"Weather is null");
    		return;
    	}

    	String strCode = weatherInfo.getCode();
    	nCode = getImageByCode(strCode);
    	m_WeatherIcon.setImageResource(nCode);
    	
    	boolean bIsC = m_Preferneces.getTempFmt();
    	
    	String strFmt;
    	String strTemp = weatherInfo.getTemperature(WeatherInfo.TEMPERATURE_FMT_CELSIUS);
    	if (bIsC == true){
    		strFmt = getString(R.string.str_temperature_fmt); 
    	} else {
    		strFmt = getString(R.string.str_temperature_fmt_f);
    		strTemp = WeatherDataModel.convertC2F(strTemp);
    	}
    	
    	String strTemperature = String.format(strFmt, strTemp);
      
    	m_TextLocation.setText(weatherInfo.getCity());
    	m_Temperature.setText(strTemperature);
    	strTemp = strTemperature;
    	DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    	Date date = new Date();
    
    	m_Date.setText(dateFormat.format(date));
    	strFmt = getString(R.string.str_humidity_fmt);
    	String strHumidity = String.format(strFmt, weatherInfo.getHumidity());
    	m_Humimidy.setText(strHumidity);
    	strFmt = getString(R.string.str_visi_fmt);
    	String strVisi = String.format(strFmt, weatherInfo.getVisibility());
    	m_Visibility.setText(strVisi);
    	
    	startSer();
    	
    }
   
  
    private int getImageByCode(String strCode){
    	int nImageCode = R.drawable.a0;
    	
    	if (strCode == null){
    		Log.e(TAG,"Code is null");
    		return nImageCode;
    	}
    	
    	int nCode = Integer.parseInt(strCode);
    	
    	int nNumber= YahooWeatherHelper.m_ImageArr.length;
    	for (int i=0; i < nNumber; i++){
    		if (nCode == YahooWeatherHelper.m_ImageArr[i][1]){
    			return YahooWeatherHelper.m_ImageArr[i][0];
    		}
    	}
    	return nImageCode;
    }
    

    private void drawTitle(){
    	setTitle(R.string.strSettingTitle);
    }
    
   
    AlertDialog.Builder contextMenu;
	private AlertDialog createContextMenuSetting(Context context){
		AlertDialog dialogMenu = null;
		List<ContextMenuItem> arrMenuItem = null;
		contextMenu = new AlertDialog.Builder(context);

		arrMenuItem = _createContextMenuList();
		if (arrMenuItem == null){
			Log.e(TAG,"Can note create dialog item");
			return null;
		}

		this.m_contextAdapter = new ContextMenuAdapter(context,
				0, arrMenuItem);
		contextMenu.setAdapter(m_contextAdapter, new HandleSelectContextMenu());
		contextMenu.setInverseBackgroundForced(true);
		contextMenu.setTitle(R.string.title_context_menu_setting);
		contextMenu.setIcon(R.drawable.set1);

		
		dialogMenu = contextMenu.create();
		dialogMenu.setCanceledOnTouchOutside(true);
		
		return dialogMenu;
	}
	ContextMenuItem itemContext1;
	private List<ContextMenuItem> _createContextMenuList(){
		ArrayList<ContextMenuItem> arrMenuItem = new ArrayList<ContextMenuItem>();

		itemContext1 = new ContextMenuItem(
				0,
				R.string.context_menu_changeLocation,
				R.drawable.default_menu_item);

		ContextMenuItem itemContext2 = new ContextMenuItem(
				1,
				R.string.context_menu_update_time,
				R.drawable.default_menu_item);
		
		ContextMenuItem itemContext3 = new ContextMenuItem(
				2,
				R.string.temperature_unit,
				R.drawable.default_menu_item);	
		ContextMenuItem itemContext4 = new ContextMenuItem(
				3,
				R.string.change_language,
				R.drawable.default_menu_item);		
		/*ContextMenuItem itemContext5 = new ContextMenuItem(
				4,
				R.string.notification,
				R.drawable.default_menu_item);		
		*/
		arrMenuItem.add(itemContext1);
		arrMenuItem.add(itemContext2);
		arrMenuItem.add(itemContext3);
		arrMenuItem.add(itemContext4);
		//arrMenuItem.add(itemContext5);
		
		return arrMenuItem;
	}		
	
	private class HandleSelectContextMenu implements 
					android.content.DialogInterface.OnClickListener{
	
		public void onClick(DialogInterface dialog, int which) {
			
			switch (which){
			case 0:
				selectSetting();
				break;

			case 1:
				selectTimeIntervalUpdating();
				break;
				
			case 2:
				selectTempFormat();
				break;
			case 3:
			  selectLanguage();
				break;
		/*	case 4:
				  notification();
					break;*/
		
			
				default:
					Log.e(TAG,"Invalid context menu");
					break;
			}
		}

	
	}
	private void notification() {
		
    	final String[] items = {getResources().getString(R.string.startnotification), getResources().getString(R.string.stopnotification)};

    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	builder.setTitle(R.string.notification);
    	builder.setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener() {
    	    public void onClick(DialogInterface dialog, int item) {
    	     
    	    	
    	    	switch( item ){
    	    	case 0:
    	    		//startSer();
    	    		break;
    	    	case 1:
    	    		//stopSer();
    	    		break;
    	    
    	    		default:
    	    			break;
    	    	}

    	    	m_Alert.dismiss();
    	    	
    	    }
    	});
    	
    	m_Alert = builder.create();  
    	m_Alert.show();
}	
	private void selectWeatherSetting(){
		m_Dialog = createContextMenuSetting(this);
		if (m_Dialog != null){
			m_Dialog.show();
		}		
	}
	public String getFolkText()
	{
		int randomNum = 1 + (int)(Math.random()*folkWeather.length); 
		String randomFolkText = folkWeather[randomNum];
		return randomFolkText;
	}
	public String getNarodneText()
	{
		int randomNum = 1 + (int)(Math.random()*narodneIzreke.length); 
		String randomFolkText = narodneIzreke[randomNum];
		return randomFolkText;
	}
	String[] folkWeather ={"The moon and the weather may change together, But a change of the moon, will not change the weather.",

			"A ring around the sun or moon, means rain or snow coming soon.",

			"When grass is dry at morning light Look for rain before the night.",

			"Dew on the grass, rain won't come to pass.",

			"Sea gull, sea gull, sit on the sand, It's never good weather while you're on the land.",

			"When sea-gulls fly to land, a storm is at hand.",

			"Rain before seven, fine before eleven. ",
			"Evening red and morning grey, two sure signs of one fine day.",

			"The sudden storm lasts not three hours The sharper the blast, the sooner 'tis past.",

			"The higher the clouds the better the weather.",

			"Cold is the night when the stars shine bright.",

			"Sound travelling far and wide, a stormy day betide.",

			"When the forest murmurs and the mountain roars, Then close your windows and shut your doors.",

			"When leaves show their undersides, be very sure that rain betides.",

			"Chimney smoke descends, our nice weather ends.",

			"When the night goes to bed with a fever, it will awake with a wet head.",

			"When stars shine clear and bright, We will have a very cold night.",

			"When the ditch and pond offend the nose, Then look out for rain and stormy blows.",

			"Three days rain will empty any sky.",

			"The farther the sight, the nearer the rain.",

			"Rain long foretold, long last, Short notice, soon will pass.",

			"The sharper the blast, the sooner 'tis past.",

			"If bees stay at home, rain will soon come, If they flay away, fine will be the day.",

			"The first and last frosts are the worst.",

			"When clouds look like black smoke a wise man will put on his cloak.",

			"A rainbow afternoon, Good weather coming soon.",

			"A rainbow in the morning, is the shepherd's warning A rainbow at night is the shepherd's delight.",

			"When the chairs squeak, it's of rain they speak.",

			"Catchy drawer and sticky door, Coming rain will pour and pour.",

			"The winds of the daytime wrestle and fight, Longer and stronger than those of the night.",

			"Dust rising in dry weather is a sign of approaching change.",

			"Sun sets Friday clear as bell, Rain on Monday sure as hell.",

			"No weather's ill if the wind be still.",

			"The squeak of the snow will the temperature show.",

			"When smoke hovers close to the ground, there will be a weather change.",

			"When down the chimney falls the soot Mud will soon be underfoot.",

			"When the sun shines while raining, it will rain the same time again tomorrow.",

			"When the wind blows from the west, fish bite best. ",
			"When it blows from the east, fish bite least.",

			"If salt is sticky, And gains in weight; It will rain Before too late.",

			"Red sky at night, sailor's delight; Red sky in morning, sailor take warning.",

			"When clouds appear like rocks and towers, The Earth's refreshed by frequent showers.",

			"When the wind is in the east, 'tis neither good for man nor beast.",

			"The more cloud types present, the greater the chance of rain or snow. ",

			"Hornets’ nest built in the top of trees indicate a mild winter is ahead; nests built close to the ground indicate that a harsh winter is coming.",
			"The higher the clouds the better the weather.",
			"If the cat washes her face over her ear, the weather is sure to be fine and clear.",
			"Clear moon, frost soon.",
			"When leaves fall early, autumn and winter will be mild; when leaves fall later, winter will be severe.",
			"If March comes in like a lion, it will go out like a lamb.",
			"When ants travel in a straight line expect rain; when they are scattered, expect fair weather.",
			"If the first snow falls on unfrozen ground expect a mild winter.",
			"If bees stay at home rain will soon come; if they fly away, fine will be the day.",
			"A year of snow, a year of plenty.",
			"Dust rising in dry weather is a sign of approaching change.",
			"Rainbow at noon, more rain soon.",
			"Flowers blooming in late autumn are a sign of a bad winter.",
			"If cows lie down and refuse to go to pasture, you can expect a storm to blow up soon.",
			"The darker the woolly caterpillar’s coat, the more severe the winter will be. If there is a dark stripe at the head and one at the end, the winter will be severe at the beginning, become mild, and then get worse just before spring.",
			"When grass is dry at morning light look for rain before the night.",
			"If sheep ascend hills and scatter, expect clear weather.",
			"A warm November is the sign of a bad winter.",
			"When the chairs squeak, it’s of rain they speak.",
			"When clouds appear like rocks and towers, the earth will be washed by frequent showers.",
			"If birds fly low, then rain we shall know.",
			"Evening red and morning grey are two sure signs of one fine day.",
			"The first and last frosts are the worst.",
			"The winds of the daytime wrestle and fight longer and stronger than those of the night.",
			"When down the chimney falls the soot, mud will soon be underfoot.",
			"Rain before seven, fine before eleven.",
			"No weather is ill, if the wind be still.",
			"Cold is the night when the stars shine bright.",
			"When a rooster crows at night there will be rain by morning.",
			"Dandelion blossoms close before there will be a rain.",
			"When clouds look like black smoke a wise man will put on his cloak.",
			"A cow with its tail to the West makes the weather best; a cow with its tail to the East makes the weather least.",
			"The moon and the weather may change together, but a change of the moon will not change the weather.",
			"The sudden storm lasts not three hours.",
			"Chimney smoke descends, our nice weather ends.",
			"A rainbow in the morning is the shepherd’s warning. A rainbow at night is the shepherd’s delight.",
			"Three days rain will empty any sky.",
			"When smoke hovers close to the ground there will be a weather change.",
			"A ring around the sun or moon means rain or snow coming soon.",
			"Bees will not swarm before a storm.",
			"The more cloud types present the greater the chance of rain or snow.",
			"Catchy drawer and sticky door, coming rain will pour and pour.",
			"When the wind blows from the west, fish bite best. When it blows from the east, fish bite least.",
			"When leaves show their undersides, be very sure that rain betides.",
			"Birds on a telephone wire predict the coming of rain.",
			"When the ditch and pond offend the nose, then look out for rain and stormy blows.",
			"Pigs gather leaves and straw before a storm.",
			"Trout jump high, when a rain is nigh.",
			"Red sky at morning, sailor take warning; red sky at night, a sailor’s delight.",
			"When the night goes to bed with a fever, it will awake with a wet head."
	};
	
	String[] narodneIzreke = {"Ako je oko mjeseca veliki krug. sutradan će duvati vjetar.",
			"Ako lastavice lete visoko, bit će lijepo vrijeme.",
			"Kad lastavice lete nisko i cvrkuću, eto nam kiše.",
			"Ako kokoši idu rano na počinak. dogodit će se promjena vremena.",
			"Ako kokoši idu kasno legati. bit će kiše.",
			"Ako je johino lišće Ijepijivo od medene rose, bit će kiše.",
			"Ako pijetao stoji ili hoda po kiši. kiša će nastaviti padati.",
			"Ako pijetao kukuriče u podne, bit će kiše.",
			"Ako se mačka umiva i uređuje. bit će lijepo vrijeme.",
			"Dok je sol suha ostat će lijepo vijeme, a kada postane mokra, slijedi kiša.",
			"Ako se dim vije i spušta niz krov. bit će kiše.",
			"Ako vjetar puše ujutro, prije izlaska sunca, bit če kiše taj dan.",
			"Ako te bole noge ili bedra. doći će do promjene vremena.",
			"Vedra noc bez rose i vjetra znače kišu.",
			"Ako vam se jako zijeva, vrijeme će se promijeniti.",
			"Zapadne li sunce za oblak, bit ce kiše, a zapadne li dok je nebo vedro, bit će lijepo vrijeme.",
			"Kada đaba krekeće i skriva se pod lišćem, bit će kiše.",
			"Ako je blago u štali nemirno, dogodit će se nevrijeme.",
			"Ako su latice perunike uzdignute. doći će kiša.",
			"Što je muha dosadnija, to je kiša bliža.",
			"Ako oko kuće ima puno vrabaca, zima će biti dugačka i hladna.",
			"Kada krtica miruje, doći će lijepo vrijeme.",
			"Kad krtica puno ruje. doći će kiša.",
			"Obilna rosa ujutro — lijepo vrijeme cijeli dan.",
			"Ako u rano proljeće žabe puno krekeću, bit će toplo vrijeme.",
			"Ako mačak rep drži u vis, bit će lijepo vrijeme.",
			"Ako zvijezde na nebu jako trepću, bit će lijepo vrijeme.",
			"Kad ševa pjeva visoko u zraku, dolazi kiša.",

			"Ako mravi izlaze iz zemlje. bit će kiše i nevremena.",
			"Ako pčele puno lete oko košnice, bit će kiše.",
			"Ako pčele rade za vrijeme oblačnog vremena, stići će sunčano i lijepo.",
			"Kada se pauk skriva, dolazi nam kiša.",
			"Ako su komarci napasni i skrivaju se u sjeni, doći će kiša.",
			"Ako se pijetao kupa u prašini, stiže nam lijepo vrijeme.",
			"Kada u jesen vrane lete s polja, uskoro stiže snijeg.",
			"Ako je vedra noć i sove huču, doći će do promjene vremena, odnosno kiše.",
			"Mnogo magle u oktobru, mnogo snijega u zimu.",

			"Grmljavina u zimi — još veća hladnoća će pritisnuti.",
			"Ne možeš vjerovati zimskoj vedrini ni ljetnim oblacima.",
			"Januarska kiša sve usjeve šiša.",

			"Od svetog Ilije sunce sve milije.",

			"Ako je uoči Miholja vedra noć, zima će imati veliku moć.",

			"Ako na Miholje sjever vuče, veliku zimu i snijeg dovuče.",

			"Kiša Miholja, do Božića blaga zima.",

			"Kad decembrom traju snijeg i zima, onda zamlja žitom rodit ima.",

			"Decembarska mokrina, mokra godina.",

			"Decembar godinu rađa.",

			"Decembar suv vjetar pišti, proljeće suša tišti.",

			"Decembarska grmljavina, slijedeća godina vjetrove ima.",

			"Topao decembar pokvari cijelu godinu.",

			"Kad na novo ljeto sunce lijepo svijetli, ribe, voća i vina dosta ćeš imati.",

			"Ako nije januar u snijegu, teško njivi, vrtu, dolu i brijegu.",

			"Topla januara da nas Bog sačuva.",

			"Grmljavina zimska s još većom zimom pritiska.",

			"Ako u martu igraju mušice, u aprili pripremi rukavice.",

			"Martovska grmljavina, rodna godina."};

}
