package trenutna.temperatura;

import java.util.Random;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

public class ServiceNotification extends Service {

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Toast.makeText(this,"Service Created",300);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this,"Service Destroy",300);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        Toast.makeText(this,"Service LowMemory",300);
    }
    String LOCATION;
    String TEMP;
    int IMAGE;
    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
        Toast.makeText(this,"Service start",300);
        Bundle extras = intent.getExtras(); 
      

      
            LOCATION = extras.getString("LOCATION");
            TEMP = extras.getString("TEMP");
            IMAGE =extras.getInt("IMAGE");
            NotificationCompat.Builder builder =
                    new NotificationCompat.Builder(this)
                            .setSmallIcon(IMAGE)
                            .setContentTitle(TEMP)
                            .setContentText(LOCATION);
            int NOTIFICATION_ID = 12345;

            Intent targetIntent = new Intent(this, ActivityWeatherSettings.class);
            PendingIntent contentIntent = PendingIntent.getActivity(this, 0, targetIntent, PendingIntent.FLAG_UPDATE_CURRENT);
            builder.setContentIntent(contentIntent);
            NotificationManager nManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nManager.notify(NOTIFICATION_ID, builder.getNotification());
    }

   /* @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
    //	super.onStartCommand(intent, flags, startId);
        Toast.makeText(this,"task perform in service",300);
        //showNotification();
      /*  ThreadDemo td=new ThreadDemo();
        td.start();
        return super.onStartCommand(intent, flags, startId);
    }*/
    
    /*private class ThreadDemo extends Thread{
        @Override
        public void run() {
            super.run();
            try{
            sleep(70*1000);    
            handler.sendEmptyMessage(0);
            }catch(Exception e){
                e.getMessage();
            }
        }
    }
   private Handler handler=new Handler(){
    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);
        showNotification();
    }
   };*/
  /* public void showNotification()
   {
	   Intent intent = new Intent(this, ActivityWeatherSettings.class);
	   PendingIntent pIntent = PendingIntent.getActivity(this, 0, intent, 0);

	  
	   Notification n  = new Notification.Builder(this)
	           .setContentTitle("")
	           .setContentText("")
	           .setSmallIcon(R.drawable.icon)
	           .setContentIntent(pIntent)
	           .setAutoCancel(true)
	           .addAction(R.drawable.icon, "Call", pIntent)
	           .addAction(R.drawable.icon, "More", pIntent)
	           .addAction(R.drawable.icon, "And more", pIntent).build();


	   NotificationManager notificationManager = 
	     (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

	   notificationManager.notify(0, n); 
   }*/
}